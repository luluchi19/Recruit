/* eslint-disable @typescript-eslint/no-explicit-any */
declare module "just-validate" {
  const JustValidate: any;
  export default JustValidate;
}
